//Index
import { App } from "./app";

App.start()
App.config({
    first: 1,
    last: 100
})
